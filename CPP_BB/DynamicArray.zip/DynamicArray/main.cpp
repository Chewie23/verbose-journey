#include <iostream>

#include "DynamicArray.h"

using namespace std;

int main() {
  DynamicArray<int> nums;
  nums.push_back(12);
  nums.push_back(34);
  nums.push_back(56);
  nums.push_back(78);
  
  nums.pop_back();
  
  std::cout <<"index 0: " << nums[0] << std::endl; //works


  for (const int& x : nums) {
    cout << x << endl;
  }
  cout << endl;
}

  /*
  nums.pop_back();
  nums[0] = '0';
  nums[1] = 'A';
  nums[2] = 'a';
  for (const int& x : nums) {
    cout << x << endl;
  }
  return 0;
}

/* OUTPUT
12
34
56
78

48
65
97
*/